<?php 
	#variable pour faire connexion au BD
    define('DB_HOST', 'localhost');
    define('DB_USER', 'id21687881_mohamed');
    define('DB_PASSWORD', 'Mohamed123456@');
    define('DB_NAME', 'id21687881_my_app');

	#variable pour etat d'USER dans BD
    define('USER_CREATED', 101);
    define('USER_EXISTS', 102);
    define('USER_FAILURE', 103); 

    #user login option 3 possibility
    define('USER_AUTHENTICATED', 201);
    define('USER_NOT_FOUND', 202); # email not found for user
    define('USER_PASSWORD_DO_NOT_MATCH', 203);

    define('PASSWORD_CHANGED', 301);
    define('PASSWORD_DO_NOT_MATCH', 302);
    define('PASSWORD_NOT_CHANGED', 303); #other errors

    