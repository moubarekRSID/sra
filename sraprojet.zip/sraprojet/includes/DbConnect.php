<?php 

    class DbConnect{

        private $con; 

        function connect(){
		#dirname(__FILE)__ return cuurent directory
            include_once dirname(__FILE__)  . '/Constants.php';

            $this->con = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME); 

            if(mysqli_connect_errno()){
		#return actual error message
                echo "Failed  to connect " . mysqli_connect_error(); 
                return null; 
            }

            return $this->con; 
        }

    }